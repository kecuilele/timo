package com.linln.admin.dictionary.validator;

import lombok.Data;

import java.io.Serializable;

/**
 * @author cuike
 * @date 2019/12/10
 */
@Data
public class CountrylistValid implements Serializable {
}