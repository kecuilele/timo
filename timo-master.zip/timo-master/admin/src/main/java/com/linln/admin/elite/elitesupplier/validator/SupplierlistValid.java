package com.linln.admin.elite.admin.elitesupplier.validator;

import lombok.Data;

import java.io.Serializable;

/**
 * @author 崔珂
 * @date 2019/11/18
 */
@Data
public class SupplierlistValid implements Serializable {
}