package com.linln.admin.equm.validator;

import lombok.Data;

import java.io.Serializable;

/**
 * @author cuike
 * @date 2019/11/07
 */
@Data
public class InventorysValid implements Serializable {
}