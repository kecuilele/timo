package com.linln.admin.finanace.validator;

import lombok.Data;

import java.io.Serializable;

/**
 * @author 崔珂
 * @date 2019/11/19
 */
@Data
public class FinanaceorderssValid implements Serializable {
}