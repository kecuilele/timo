package com.linln.common.utils;

import org.springframework.stereotype.Component;


/**
 * 密码加密测试类，可用于重置密码
 * @author 小懒虫
 * @date 2019/4/27
 */
@Component
public class EncryptUtilTest {

}